# ARISE — Real Life Fitness RPG

Android-only, offline, no-equipment fitness RPG starter.

## Features
- XP + levels + E→SS rank progression
- Daily quests with XP rewards
- Weekly boss concept
- Physical stats / weight
- Nutrition target dashboard
- Daily 7 PM workout notification
- Local SharedPreferences storage

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then:
Build → Build APK(s)

The generated debug APK is under:
app/build/outputs/apk/debug/

## Notes
This is V1. Nutrition food logging, exercise library, animations, sound effects, backup/export, and richer progression can be added in V2.
