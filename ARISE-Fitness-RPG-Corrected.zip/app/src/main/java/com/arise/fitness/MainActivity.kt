package com.arise.fitness

import android.app.*
import android.content.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private val Bg = Color(0xFF090A0F)
private val Card = Color(0xFF141720)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)
private val Text = Color(0xFFF5F7FF)
private val Muted = Color(0xFF9CA3AF)

data class Quest(val title:String,val detail:String,val xp:Int,var done:Boolean=false)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("arise", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 10)
        scheduleNotification()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background=Bg, surface=Card, primary=Purple,
                onBackground=Text, onSurface=Text
            )) {
                AriseApp(prefs)
            }
        }
    }

    private fun scheduleNotification() {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, WorkoutReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 99, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val c=Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,19);set(Calendar.MINUTE,0);set(Calendar.SECOND,0) }
        if(c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1)
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
    }
}

class WorkoutReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val channel="arise_workout"
        val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(android.os.Build.VERSION.SDK_INT>=26)
            nm.createNotificationChannel(NotificationChannel(channel,"Workout",NotificationManager.IMPORTANCE_DEFAULT))
        val n=Notification.Builder(context,channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⚔️ ARISE — Daily Quest")
            .setContentText("Bhai, workout ka time ho gaya. Aaj ka quest complete kar! +XP 🔥")
            .setAutoCancel(true).build()
        nm.notify(101,n)
    }
}

@Composable
fun AriseApp(prefs: android.content.SharedPreferences) {
    var tab by remember { mutableIntStateOf(0) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp",820)) }
    var weight by remember { mutableStateOf(prefs.getString("weight","58.0") ?: "58.0") }
    var quests by remember { mutableStateOf(listOf(
        Quest("Push-ups","30 reps",30),
        Quest("Bodyweight Squats","50 reps",40),
        Quest("Plank","60 seconds",40),
        Quest("Full Workout","Complete today's workout",100)
    )) }
    var showLevel by remember { mutableStateOf(false) }

    val level = 1 + xp / 1000
    val inLevel=xp%1000
    val rank=when { level>=50->"SS"; level>=35->"S"; level>=25->"A"; level>=15->"B"; level>=8->"C"; level>=3->"D"; else->"E" }

    if(showLevel) {
        LevelUpDialog(level) { showLevel=false }
    }

    Scaffold(
        containerColor=Bg,
        bottomBar={
            NavigationBar(containerColor=Color(0xFF0D0F16)) {
                listOf("Home","Quests","Nutrition","Stats").forEachIndexed { i,n ->
                    NavigationBarItem(selected=tab==i,onClick={tab=i},
                        icon={Icon(if(i==0) Icons.Default.Home else if(i==1) Icons.Default.Flag else if(i==2) Icons.Default.Restaurant else Icons.Default.Person,n,null)},
                        label={Text(n)})
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(18.dp)) {
            when(tab) {
                0 -> Home(xp,inLevel,level,rank,weight,quests) { q ->
                    quests=quests.map { if(it.title==q.title && !it.done) it.copy(done=true) else it }
                    val oldLevel=1+xp/1000
                    xp += q.xp
                    prefs.edit().putInt("xp",xp).apply()
                    if(1+xp/1000>oldLevel) showLevel=true
                }
                1 -> QuestScreen(quests) { q ->
                    quests=quests.map { if(it.title==q.title && !it.done) it.copy(done=true) else it }
                    val oldLevel=1+xp/1000; xp+=q.xp
                    prefs.edit().putInt("xp",xp).apply()
                    if(1+xp/1000>oldLevel) showLevel=true
                }
                2 -> Nutrition()
                3 -> Stats(weight,{weight=it;prefs.edit().putString("weight",it).apply()},level,rank)
            }
        }
    }
}

@Composable fun Header() {
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
        Text("⚔️ ARISE",fontSize=27.sp,fontWeight=FontWeight.Black,color=Text)
        Text("REAL LIFE RPG",fontSize=11.sp,fontWeight=FontWeight.Bold,color=Cyan)
    }
}
@Composable fun Home(xp:Int,inLevel:Int,level:Int,rank:String,weight:String,quests:List<Quest>,onDone:(Quest)->Unit) {
    Header(); Spacer(Modifier.height(18.dp))
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Card)) {
        Column(Modifier.padding(20.dp)) {
            Text("PLAYER",color=Muted,fontSize=12.sp); Text("LEVEL $level  •  RANK $rank",fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp)); LinearProgressIndicator({inLevel/1000f},Modifier.fillMaxWidth(),color=Purple)
            Text("$inLevel / 1000 XP",color=Muted,modifier=Modifier.padding(top=6.dp))
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Stat("WEIGHT","$weight kg"); Stat("STREAK","7 🔥"); Stat("QUESTS","${quests.count{it.done}}/${quests.size}")
            }
        }
    }
    Spacer(Modifier.height(20.dp)); Text("⚔️ TODAY'S QUESTS",fontSize=18.sp,fontWeight=FontWeight.Bold)
    quests.forEach { q -> QuestCard(q,onDone) }
}
@Composable fun QuestScreen(quests:List<Quest>,onDone:(Quest)->Unit) {
    Header(); Spacer(Modifier.height(18.dp)); Text("DAILY QUESTS",fontSize=24.sp,fontWeight=FontWeight.Black)
    Text("Complete real-world tasks to earn XP.",color=Muted)
    quests.forEach { QuestCard(it,onDone) }
    Spacer(Modifier.height(20.dp))
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFF201527)),shape=RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp)){ Text("👹 WEEKLY BOSS",fontSize=19.sp,fontWeight=FontWeight.Bold); Text("5 workouts + 300 push-ups + 500 squats",color=Muted); Text("REWARD  +500 XP",color=Cyan,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp)) }
    }
}
@Composable fun QuestCard(q:Quest,onDone:(Quest)->Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical=6.dp),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)){ Text(q.title,fontWeight=FontWeight.Bold,fontSize=16.sp); Text(q.detail,color=Muted,fontSize=13.sp); Text("+${q.xp} XP",color=Cyan,fontWeight=FontWeight.Bold) }
            Button(onClick={if(!q.done) onDone(q)},enabled=!q.done) { Text(if(q.done)"✓ DONE" else "ARISE") }
        }
    }
}
@Composable fun Nutrition() {
    Header(); Spacer(Modifier.height(18.dp)); Text("🍗 NUTRITION",fontSize=25.sp,fontWeight=FontWeight.Black)
    Text("Daily target • editable later",color=Muted)
    Spacer(Modifier.height(15.dp))
    listOf("Calories" to "2700 kcal","Protein" to "120 g","Carbs" to "300 g","Fat" to "70 g").forEach {
        Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(16.dp)) {
            Row(Modifier.fillMaxWidth().padding(18.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(it.first,fontWeight=FontWeight.Bold);Text("0 / ${it.second}",color=Cyan)}
        }
    }
    Spacer(Modifier.height(15.dp)); Text("Food logging can be added from the + button in the next version.",color=Muted)
}
@Composable fun Stats(weight:String,setWeight:(String)->Unit,level:Int,rank:String) {
    Header(); Spacer(Modifier.height(18.dp)); Text("👤 PLAYER STATS",fontSize=25.sp,fontWeight=FontWeight.Black)
    Card(Modifier.fillMaxWidth().padding(vertical=10.dp),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("PHYSICAL DATA",color=Muted,fontSize=12.sp)
            OutlinedTextField(weight,setWeight,label={Text("Weight (kg)")},singleLine=true,modifier=Modifier.fillMaxWidth().padding(top=8.dp))
            Spacer(Modifier.height(16.dp))
            listOf("STR" to (50+level*2),"END" to (45+level*2),"VIT" to (40+level),"AGI" to (35+level),"DISC" to (30+level*2)).forEach { Stat(it.first,it.second.toString()) }
        }
    }
    Text("🏆 ACHIEVEMENTS",fontSize=19.sp,fontWeight=FontWeight.Bold)
    Text("🔥 First Blood  •  Complete your first quest",color=Muted,modifier=Modifier.padding(top=10.dp))
    Text("⚔️ Consistent Hunter  •  7-day streak",color=Muted,modifier=Modifier.padding(top=8.dp))
    Text("👑 Monarch  •  Reach Level 50",color=Muted,modifier=Modifier.padding(top=8.dp))
}
@Composable fun Stat(name:String,value:String) {
    Column(horizontalAlignment=Alignment.CenterHorizontally){Text(name,color=Muted,fontSize=10.sp);Text(value,fontWeight=FontWeight.ExtraBold,fontSize=18.sp)}
}
@Composable fun LevelUpDialog(level:Int,onClose:()->Unit) {
    AlertDialog(onDismissRequest=onClose,confirmButton={Button(onClick=onClose){Text("CONTINUE")}},
        title={Text("⚔️ LEVEL UP!",fontWeight=FontWeight.Black,fontSize=28.sp)},
        text={Column{Text("LEVEL $level UNLOCKED",fontWeight=FontWeight.Bold,fontSize=20.sp);Spacer(Modifier.height(10.dp));Text("+5 STR   +3 END   +2 VIT",color=Cyan,fontWeight=FontWeight.Bold);Text("Keep going, Hunter.")}})
}
